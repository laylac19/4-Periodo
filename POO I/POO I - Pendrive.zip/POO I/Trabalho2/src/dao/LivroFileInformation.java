
package dao;

public class LivroFileInformation {
    private static String nomeArquivo = "livro.txt";
    private static String caminhoArquivo = "";

    public static String getCaminhoArquivo() {
        return caminhoArquivo;
    }

    public static String getNomeArquivo() {
        return nomeArquivo;
    }

    
}
