package domain;

import java.util.Comparator;

public class ComparatorLivroPorAutorCrescente implements Comparator<Livro> {
    public int compare(Livro o1, Livro o2) {
        return o1.getAutor().compareTo(o2.getAutor());
    }
    
}
