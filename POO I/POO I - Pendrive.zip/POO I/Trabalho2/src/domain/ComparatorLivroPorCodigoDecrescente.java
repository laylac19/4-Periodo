/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package domain;

import java.util.Comparator;

/**
 *
 * @author Giovany
 */
public class ComparatorLivroPorCodigoDecrescente implements Comparator<Livro> {
    public int compare(Livro o1, Livro o2) {
        if (o1.getCodigo() < o2.getCodigo()) {
            return 1;
        }
        else {
            return -1;
        }
    }
}
