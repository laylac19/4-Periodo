/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package domain;

import java.util.Comparator;

public class ComparatorLivroPorTituloDecrescente implements Comparator<Livro> {
    public int compare(Livro o1, Livro o2) {
        return ((-1) * o1.getTitulo().compareTo(o2.getTitulo()));
    }
}
