package domain;

import java.util.Comparator;

public class ComparatorLivroPorDataCompraDecrescente implements Comparator<Livro> {
    public int compare(Livro o1, Livro o2) {
        return ((-1) * o1.getDatacompra().compareTo(o2.getDatacompra()));
    }       
}
