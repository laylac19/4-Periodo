/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.util.Comparator;

/**
 *
 * @author layla
 */
public class ComparatorLivroPorValorCrescente implements Comparator<Livro> {
    public int compare(Livro o1, Livro o2) {
        if (o1.getValor() > o2.getValor()) {
            return 1;
        }
        else {
            return -1;
        }
    }
}
