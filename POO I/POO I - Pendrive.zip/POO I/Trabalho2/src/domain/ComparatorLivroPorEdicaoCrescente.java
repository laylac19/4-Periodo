package domain;

import java.util.Comparator;

public class ComparatorLivroPorEdicaoCrescente implements Comparator<Livro> {
    public int compare(Livro o1, Livro o2) {
        if (o1.getEdicao() > o2.getEdicao()) {
            return 1;
        }
        else {
            return -1;
        }
    }
}
