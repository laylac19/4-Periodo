package control;

import windows.JanelaPrincipalLivro;
import windows.JanelaVisualizarLivro;


public class ControladoraPrincipal {
    public static void main(String argsp[])
    {
        JanelaVisualizarLivro janela = new JanelaPrincipalLivro();
        janela.executar();
    }

}