/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulado3;

/**
 *
 * @author 2020122760102
 */
abstract public class Soccer2D extends Equipe {
    protected String logo;

    public Soccer2D(String logo, int qtAtualMembros, int qtMaxMembros) {
        super(qtAtualMembros, qtMaxMembros);
        this.logo = logo;
    }
}
