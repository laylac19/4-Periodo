
package usaencapsulamento;

public class UsaEncapsulamento {

    public static void main(String[] args) {
        
    }
    
}
