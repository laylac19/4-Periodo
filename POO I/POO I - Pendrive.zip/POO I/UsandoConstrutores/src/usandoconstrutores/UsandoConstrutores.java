/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usandoconstrutores;

/**
 *
 * @author giovanyfrossard
 */
public class UsandoConstrutores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente c1 = new Cliente("Pedro", 50);
        System.out.println(c1.nome + " possui " + c1.idade + " anos ");
        
        Cliente c2 = new Cliente();
        System.out.println(c2.nome + " possui " + c2.idade + " anos ");
    }
    
}
