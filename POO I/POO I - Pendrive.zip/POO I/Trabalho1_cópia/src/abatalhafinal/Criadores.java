package abatalhafinal;

import abatalhafinal.Feiticeiros;

public class Criadores extends Feiticeiros {
    //ataque = 10
    
    //ciador ataca e cria
    
    //habilidade = criar Shikigamis
        //energia qualquer valor
        //ataque valor aleatório 0 a 30 na criacao
        //morre junto com um criador
        //nao e atacado
    
    private int ataque;

    public Criadores(int codigo, String nome, int peso, double altura, int qtdeArmas, String regiao) {
        super(codigo, nome, peso, altura, qtdeArmas, regiao);
        this.ataque = 10;
    }

    @Override
    public void setAtaque(int ataque) {
        super.setAtaque(10); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void habilidadeEspecial() {
        //criar shikigamis
    }
}
