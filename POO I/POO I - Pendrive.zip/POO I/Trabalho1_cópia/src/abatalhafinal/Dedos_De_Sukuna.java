/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;
import abatalhafinal.Maldicoes;
import abatalhafinal.Ser;
import java.util.Random;

/**
 *
 * @author layla
 */
public class Dedos_De_Sukuna extends Maldicoes {

    public Dedos_De_Sukuna(int codigo, String nome, int peso, double altura, String obscuro) {
        super(codigo, nome, peso, altura, obscuro);
    }

    @Override
    void habilidadeEspecial(Ser ser2) {
      int op;
      Random valor = new Random();
      
      op = valor.nextInt(2) + 1;
      
      if(op == 1){
          ser2.energia = 0;
        }else{
          this.energia = 100;
      }
      
            
        //HABILIDADE 1:
            //50% de chance de matar feiticeiros
            
        //HABILIDADE 2:
            //Recupera a vida toda se não matar feiticeiro/
    }

    @Override
    void habilidadeEspecial() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
