package abatalhafinal;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Random;

public class Principal {
    //LinkedList<Ser> feiticeiros = new LinkedList<Ser>(); // lista de feiticeiros
    // feiticeiros = lerArqF();

    public static LinkedList<Ser> lerArqF() throws FileNotFoundException {
        LinkedList<Ser> feiticeiros = new LinkedList<Ser>(); // lista de feiticeiros

        try {
            FileInputStream file = new FileInputStream("Feiticeiros.txt");
            Scanner scan = new Scanner(file);
            String[] vet = new String[0];

            while (scan.hasNext()) {
                String line = scan.nextLine();
                vet = line.split(" ");

                int codigo = Integer.parseInt(vet[0]);
                String nome = vet[1];
                int peso = Integer.parseInt(vet[2]);
                double altura = Double.parseDouble(vet[3]);
                int qtdeArmas = Integer.parseInt(vet[4]);
                String regiao = vet[5];

                switch (codigo) // Pelo código do carro, eu sei qual carro add na lista
                {
                    case 1:
                        feiticeiros.add(new Trocadores(1, nome, peso, altura, qtdeArmas, regiao));
                        //Feiticeiros = new Trocadores (1, nome, peso, altura, qtdeArmas, regiao);
                        break;
                    case 2:
                        feiticeiros.add(new Criadores(1, nome, peso, altura, qtdeArmas, regiao));
                        break;
                    case 3:
                        feiticeiros.add(new Armados(1, nome, peso, altura, qtdeArmas, regiao));
                        break;
                    case 4:
                        feiticeiros.add(new Devastadores(1, nome, peso, altura, qtdeArmas, regiao));
                        break;
                    default:
                        System.out.println("Arquivo não encontrado! \n");
                        break;
                }

            }
            scan.close();
        } catch (FileNotFoundException fileNot) {
            fileNot.getMessage();
        }
        return feiticeiros; // retornando a lista de carros lida do arquivo 'carros.txt'
    }

    //public static LinkedList<Ser> lerArqF() throws FileNotFoundException
    private static LinkedList<Ser> lerArqM() throws FileNotFoundException {
        LinkedList<Ser> maldicoes = new LinkedList<Ser>(); // lista de feiticeiros

        try {
            FileInputStream file = new FileInputStream("Maldicoes.txt");
            Scanner scan = new Scanner(file);

            while (scan.hasNext()) {
                String[] vet = new String[0];
                String line = scan.nextLine();
                vet = line.split(" ");

                int codigo = Integer.parseInt(vet[0]);
                String nome = vet[1];
                int peso = Integer.parseInt(vet[2]);
                double altura = Double.parseDouble(vet[3]);
                String humano = vet[4];

                switch (codigo) // Pelo código do carro, eu sei qual carro add na lista
                {
                    case 1:
                        maldicoes.add(new Basicas(1, nome, peso, altura, humano));
                        //Feiticeiros = new Trocadores (1, nome, peso, altura, qtdeArmas, regiao);
                        break;
                    case 2:
                        maldicoes.add(new Copiadores(2, nome, peso, altura, humano));
                        break;
                    case 3:
                        maldicoes.add(new Resistentes(3, nome, peso, altura, humano));
                        break;
                    case 4:
                        maldicoes.add(new Dedos_De_Sukuna(4, nome, peso, altura, humano));
                        break;
                    case 5:
                        maldicoes.add(new Sukunas(5, nome, peso, altura, humano));
                        break;
                    default:
                        System.out.println("Arquivo não encontrado! \n");
                        break;
                }
            }

        } catch (FileNotFoundException fileNot) {
            fileNot.getMessage();
        }
        return maldicoes; // retornando a lista de carros lida do arquivo 'carros.txt'
    }

    public static double imc(LinkedList<Ser> feiticeiros, LinkedList<Ser> maldicoes) {
        double somaIMC = 0;
        double mediaIMC;
        for (int i = 0; i < feiticeiros.size(); i++) { //percorre a lista feiticeiros
            //a cada indice calcula o imc de um objeto da lista de feiticeiros
            somaIMC += feiticeiros.get(i).calcularIMC();
        }
        for (int i = 0; i < maldicoes.size(); i++) { //percorre a lista maldicoes
            //a cada indice calcula o imc de um objeto da lista de maldicoes
            somaIMC += maldicoes.get(i).calcularIMC();
        }
        //calcula a media com a soma total do IMC dos seres nas listas divido pelo tam de ambas
        mediaIMC = somaIMC / (feiticeiros.size() + maldicoes.size());
        return mediaIMC;
    }

    public static void dadosMaldicoes(LinkedList<Ser> maldicoes) {
        //conta a qtde de S no nome da maldição e imprime todos os dados da maldição encontrada
        for (int i = 0; i < maldicoes.size(); i++) {   //percorre a lista dos seres maldicoes
            Maldicoes curse = (Maldicoes)maldicoes.get(i); 
            
            String name = curse.getNome(); //recebe o nome da maldição do indice i da lista
            int qtde = 0;

            for (int j = 0; j < name.length(); j++) { 
            // de acordo com o tamanho do nome da maldição percorre os caractres
                
                if (name.charAt(j) == 's' || name.charAt(j) == 'S' ) {
                    //conta a qtde de S minusculo e maiusculo
                    qtde++;
                }
            }
            if (qtde == 2) {
                if (name.equals(curse.nome)) { 
                //compara o nome da maldicção do indice i da lista com o da maldição do mesmo indice para imprimir os dados
                    System.out.println("Nome : " + curse.getNome() +
                                       " Peso : " + curse.getPeso() +
                                       " Altura : " + curse.getAltura() +
                                       " Obscuro : " + curse.getObscuro()
                                      );
                }
            }
        }
    }
    
    public static void dadosFeiticeiros(LinkedList<Ser> feiticeiros) {        
        //percorre a lista de feiticeiros
        for (int i = 0; i < feiticeiros.size(); i++) {   
            //acessa cada feiticeiros seguindo o indice
            Feiticeiros sorcerer = (Feiticeiros)feiticeiros.get(i);
            
            //compara a região de cada feiticeiros para mostrar na saída
            if ("Noeh".equals(sorcerer.getRegiao())) {
                String nome = sorcerer.getNome();
                int peso = sorcerer.getPeso();
                double altura = sorcerer.getAltura();
                int qtdeArmas = sorcerer.getQtdeArmas();
                String regiao = sorcerer.getRegiao();
                
                System.out.println("Nome = " + nome + 
                                   " Peso = " + peso +
                                   " Altura = " + altura +
                                   " Quantidade de Armas = " + qtdeArmas +
                                   " Regiao = " + regiao
                                  );
            }
        }
    }
    
    
    public static void batalha (LinkedList<Ser> feiticeiros, LinkedList<Ser> maldicoes){
        int nTipo = 0;
        Random select = new Random();
        
        
        for(int i =0; i <10;i++){
            nTipo = select.nextInt(2) + 1;
            Feiticeiros sorcerer = (Feiticeiros)feiticeiros.get(i);
            Maldicoes curse = (Maldicoes)maldicoes.get(i);
  
            switch (nTipo){
                    case 1:
                        System.out.println("Inicio dos feiticeiros.");
                        sorcerer.Atacar(curse);
                    break;
                    case 2:
                        System.out.println("Inicio das maldições.");
                        curse.Atacar(sorcerer);
            
                }
          
        }    
        
    }
    public static void main(String[] args) throws FileNotFoundException {

        LinkedList<Ser> feiticeiros = new LinkedList<Ser>(); // lista de feiticeiros
        LinkedList<Ser> maldicoes = new LinkedList<Ser>(); // lista de maldicoes

        feiticeiros = lerArqF(); //lista de objetos
        maldicoes = lerArqM(); //lista de objetos
        
        System.out.println("==================== SAÍDA =============================");
        
        System.out.println("----- IMC -----");
        double imcFinal = imc(feiticeiros, maldicoes);
        System.out.println("IMC Média: " + imcFinal + "\n");
        System.out.println(" ");

        System.out.println("--------------- Nome com 2 S ---------------");
        dadosMaldicoes(maldicoes);
        
        System.out.println("--------------- Feiticeiros de Noeh ---------------");
        dadosFeiticeiros(feiticeiros);
    }
}
