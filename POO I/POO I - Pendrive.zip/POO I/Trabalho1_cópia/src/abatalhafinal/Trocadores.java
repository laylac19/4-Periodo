
package abatalhafinal;

import abatalhafinal.Feiticeiros;
import abatalhafinal.Ser;

public class Trocadores extends Feiticeiros {
    
    //ataque = 20
    
    //habilidade = troca de lugar
        //rebate o ataque para a segunda maldição da fila
        //se não tiver outra maldição faz ataque padrão

    
    //construtor
    public Trocadores(int codigo, String nome, int peso, double altura, int qtdeArmas, String regiao) {
        super(codigo, nome, peso, altura, qtdeArmas, regiao);
    }
    
    @Override
    public void setAtaque(int ataque) {
        super.setAtaque(20); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int Atacar(Ser ser2) {
        return super.Atacar(ser2); //To change body of generated methods, choose Tools | Templates.
    }

    
    @Override
    void habilidadeEspecial( ) {  
        
    }


}

