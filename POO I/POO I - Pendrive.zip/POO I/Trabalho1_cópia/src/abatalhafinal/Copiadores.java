/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

import abatalhafinal.Maldicoes;

/**
 *
 * @author layla
 */
public class Copiadores extends Maldicoes {

    public Copiadores(int codigo, String nome, int peso, double altura, String obscuro) {
        super(codigo, nome, peso, altura, obscuro);
    }
    
    //habilidade = Replicacao de Fila
        //conta o num de feiticieros e cria essa qtde de maldicoes básicas no final da fila

    @Override
    void habilidadeEspecial() {
        //replicar fila
    }
}
