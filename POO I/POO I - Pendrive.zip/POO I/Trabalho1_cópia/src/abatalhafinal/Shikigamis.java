/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;
import abatalhafinal.Criadores;
import java.util.Random;

/**
 *
 * @author 2020122760102
 */
public class Shikigamis extends Criadores {

    public Shikigamis(int codigo, String nome, int peso, double altura, int qtdeArmas, String regiao) {
        super(codigo, nome, peso, altura, qtdeArmas, regiao);
    }


    @Override
    public void setAtaque(int ataque) {
        int qtAtk;
        Random valor = new Random();
        
        qtAtk = valor.nextInt(31);
        super.setAtaque(qtAtk); 
    }
}
