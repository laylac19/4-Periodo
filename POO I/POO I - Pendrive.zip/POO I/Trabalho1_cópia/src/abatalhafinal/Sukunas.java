/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

import abatalhafinal.Maldicoes;

/**
 *
 * @author layla
 */
public class Sukunas extends Maldicoes {

    public Sukunas(int codigo, String nome, int peso, double altura, String obscuro) {
        super(codigo, nome, peso, altura, obscuro);
    }


    @Override
    void habilidadeEspecial() {
        //cria 10 dedos no final da lista quando morre
    }

    @Override
    public void setAtaque(int ataque) {
        super.setAtaque(60); //To change body of generated methods, choose Tools | Templates.
    } 
}
