package abatalhafinal;
import abatalhafinal.Feiticeiros;
import java.util.Random;

public class Devastadores extends Feiticeiros {
    //this.ataque = 50;
    
    //habilidade = ATAQUE FATAL
        //a cada 3 ataques gera o ataque final 
        //a maldição VAI MORRER
    
    //habilidade 2
        //antes de atagar life aumenta 20
        //nao passa de 100;
    public Devastadores(int codigo, String nome, int peso, double altura, int qtdeArmas, String regiao) {
        super(codigo, nome, peso, altura, qtdeArmas, regiao);
    }

    @Override
    public void setAtaque(int ataque) {
        super.setAtaque(50); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void habilidadeEspecial() {
       int contador = 0;
       
       this.energia += 20;
       if (this.energia > 100){
           this.energia = 100;
       }
       
       if (contador==3){
           this.setAtaque(999);
           contador = 0;
       }
       contador++;
        // soma 3 ataques
        // ATAQUE FINAL
    }


}
