package abatalhafinal;
import abatalhafinal.Feiticeiros;

public class Armados extends Feiticeiros {
    
    public Armados(int codigo, String nome, int peso, double altura, int qtdeArmas, String regiao) {
        super(codigo, nome, peso, altura, qtdeArmas, regiao);
    }

    @Override
    public void setAtaque(int ataque) {
        super.setAtaque(5 * this.qtdeArmas); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void habilidadeEspecial() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
