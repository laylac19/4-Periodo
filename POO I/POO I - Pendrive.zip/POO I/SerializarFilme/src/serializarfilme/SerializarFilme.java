/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serializarfilme;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Logger;
import java.util.logging.Level;


/**
 *
 * @author 2020122760102
 */
public class SerializarFilme {

    private static void gravarFilme(Filme filme) throws IOException {
        FileOutputStream arquivo;
        try {
            arquivo = new FileOutputStream("filme.txt");
            //Grava o objeto filme no arquivo
            try ( //Classe responsavel por inserir o filme
                    ObjectOutputStream objGravar = new ObjectOutputStream(arquivo)) {
                //Grava o objeto filme no arquivo
                objGravar.writeObject(filme);
                objGravar.flush();
            }
            arquivo.flush();
            arquivo.close();
        } catch (FileNotFoundException ex) {

            Logger.getLogger(SerializarFilme.class.getName()).log(Level.SEVERE, null,
                    ex);
        } catch (IOException ex) {

            Logger.getLogger(SerializarFilme.class.getName()).log(Level.SEVERE, null,
                    ex);
        }
    }
    
    private static Filme obterFilme() throws FileNotFoundException, IOException, ClassNotFoundException {
        Filme filme = null;
        try {
            if (!estaArquivoVazio()) {
                String local_arquivo = "filme.txt";
                try (FileInputStream arquivoLeitura = new FileInputStream(local_arquivo); ObjectInputStream objLeitura = new ObjectInputStream(arquivoLeitura)) {
                    filme = (Filme) objLeitura.readObject();
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SerializarFilme.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SerializarFilme.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SerializarFilme.class.getName()).log(Level.SEVERE, null, ex);
        }
        return filme;
    }

    private static boolean estaArquivoVazio() throws FileNotFoundException,
            IOException {
        //Carrega o arquivo
        String local_arquivo = "filme.txt";
        boolean estaVazio;
        try (FileInputStream arquivoLeitura = new FileInputStream(local_arquivo)) {
            estaVazio = (arquivoLeitura.read() == -1);
        }
        return estaVazio;
    }

    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
        Filme filme = new Filme();
        filme.setCodigo("10");
        filme.setNome("Pedro");
        filme.setGenero("Comedia");
        filme.setDatacompra("04/04/2012");
        filme.setProdutora("Warner");
        gravarFilme(filme);
        Filme filme2 = obterFilme();
        System.out.println("O código é " + filme2.getCodigo());
        System.out.println("O nome é " + filme2.getNome());
        System.out.println("O genero é " + filme2.getGenero());
        System.out.println("A data de compra é " + filme2.getDatacompra());
        System.out.println("A produtora é " + filme2.getProdutora());
    }
}
