/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usaclasses;

/**
 *
 * @author 2020122760102
 */
public abstract class Legume extends Alimento {
    private Legume combinacao;
    
    public Legume(double peso, String validade) {
        super(peso, validade);
    }

    public void combinar(Legume l2) {
        this.combinacao = l2; 
    }

    public String getCombinacao() {
        return this.getClass().getSimpleName() + " e " + this.combinacao.getClass(); 
    }
    
   
}
