/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usaclasses;

/**
 *
 * @author 2020122760102
 */
public class Batata extends Legume {

    public Batata(double peso, String validade) {
        super(peso, validade);
    }

    @Override
    public String getNutrientes() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
