/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usaclasses;

/**
 *
 * @author 2020122760102
 */
public abstract class Fruta extends Alimento {

    public Fruta(double peso, String validade) {
        super(peso, validade);
    }
    
}
