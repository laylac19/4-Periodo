/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usaclasses;

/**
 *
 * @author 2020122760102
 */
public abstract class Alimento {
    private double peso;
    private String validade;
    private String nome;
    private static int qtAlimento = 0;
    
    public static int getQuantidade() {
        return Alimento.qtAlimento;
    }
    
    public Alimento(double peso, String validade) {
        this.peso = peso;
        this.validade = validade;
    }

    public double getPeso() {
        return peso;
    }

    public String getValidade() {
        return validade;
    }
    
    public String getNome() {
        return this.getClass().getSimpleName();
    }

    public abstract String getNutrientes();
    
}
