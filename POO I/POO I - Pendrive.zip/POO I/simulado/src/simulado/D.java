/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulado;

/**
 *
 * @author 2020122760102
 */
public abstract class D extends Carro {

    private int qtde;
    //private String qtde;

    public D(double aceleracao, int vmax, double dirigibilidade, int propulsao) {
        super(aceleracao, vmax, dirigibilidade, propulsao);
    }

    static String getQtD() {
        System.out.println("Quantidade: " qtde);
    }

    //private String qtde;

    String getPreco(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    


}
