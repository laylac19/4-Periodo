/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulado;

/**
 *
 * @author 2020122760102
 */
public abstract class B extends Carro  {

    public B(double aceleracao, int vmax, double dirigibilidade, int propulsao) {
        super(aceleracao, vmax, dirigibilidade, propulsao);
    }

    static String getQtB() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getPreco(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
