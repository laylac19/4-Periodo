/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulado;

/**
 *
 * @author 2020122760102
 */
public abstract class Carro {
    //Carro c1 = new Camaro(4.23, 262, 1.235, 32);
    protected double aceleracao;
    protected int vmax; //velocidade máxima
    protected double dirigibilidade;
    protected int propulsao;

    public Carro(double aceleracao, int vmax, double dirigibilidade, int propulsao) {
        this.aceleracao = aceleracao;
        this.vmax = vmax;
        this.dirigibilidade = dirigibilidade;
        this.propulsao = propulsao;
    }

    public double getAceleracao() {
        return aceleracao;
    }

    public int getVmax() {
        return vmax;
    }

    public double getDirigibilidade() {
        return dirigibilidade;
    }

    public int getPropulsao() {
        return propulsao;
    }

    public void setAceleracao(double aceleracao) {
        this.aceleracao = aceleracao;
    }

    public void setVmax(int vmax) {
        this.vmax = vmax;
    }

    public void setDirigibilidade(double dirigibilidade) {
        this.dirigibilidade = dirigibilidade;
    }

    public void setPropulsao(int propulsao) {
        this.propulsao = propulsao;
    }

    @Override
    public String toString() {
        return "Aceleracao = " + aceleracao + ", Velocidade Máxima = " + vmax + ", Dirigibilidade = " + dirigibilidade + ", Propulsao = " + propulsao;
    }

    String getPreco() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
