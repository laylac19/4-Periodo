/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

/**
 *
 * @author 2020122760102
 */
public class Shikigamis extends Criadores {

    public Shikigamis(int codigo, String nome, int peso, double altura, int qtdeArmas, String regiao) {
        super(codigo, nome, peso, altura, qtdeArmas, regiao);
    }

    @Override
    int Atacar() {
        return super.Atacar(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setAtaque(int ataque) {
        super.setAtaque(ataque); 
    }
}
