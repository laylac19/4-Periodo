package abatalhafinal;

//Principal das Maldições
public abstract class Maldicoes extends Ser {
    protected String obscuro; //Nome indivíduo responsável pala criação da maldição
    
    //construtor
    public Maldicoes(int codigo, String nome, int peso, double altura, String obscuro) {
        super(codigo, nome, peso, altura);
        this.obscuro = obscuro;
    }

    public String getObscuro() {
        return obscuro;
    }
    
}

