package abatalhafinal;

public abstract class Feiticeiros extends Ser {
    protected int qtdeArmas;
    protected String regiao;
    private int ataque;
    //construtor
    public Feiticeiros (int codigo, String nome, int peso, double altura, int qtdeArmas,  String regiao ) {
        super(codigo, nome, peso, altura);
        this.energia = 100;
        
        this.qtdeArmas = qtdeArmas;
        this.regiao = regiao;
    }

    public int getQtdeArmas() {
        return qtdeArmas;
    }

    public String getRegiao() {
        return regiao;
    }
}