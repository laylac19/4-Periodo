/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

public abstract class Ser { //o qualificador define a visibilidade 
    private int ataque;

    //todo ser tem essas características
    protected int codigo;
    protected String nome;
    protected int peso;
    protected double altura;
    protected int energia = 0; //life
    
    //construtor
    public Ser(int codigo, String nome, int peso, double altura) {
        this.codigo = codigo;
        this.nome = nome;
        this.peso = peso;
        this.altura = altura;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public int getPeso() {
        return peso;
    }

    public double getAltura() {
        return altura;
    }

    public int getEnergia() {
        return energia;
    }
        
    public int Atacar(Ser ser2) {
        int life;
        life = ser2.energia - this.ataque;
        return life;
    }
    
    abstract void habilidadeEspecial();

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    } 
    
    
}

    
    