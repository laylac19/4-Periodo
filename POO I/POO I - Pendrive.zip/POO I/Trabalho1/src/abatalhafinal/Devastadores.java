package abatalhafinal;

public class Devastadores extends Feiticeiros {
    //this.ataque = 50;
    
    //habilidade = ATAQUE FATAL
        //a cada 3 ataques gera o ataque final 
        //a maldição VAI MORRER
    
    //habilidade 2
        //antes de atagar life aumenta 20
        //nao passa de 100;
    public Devastadores(int codigo, String nome, int peso, double altura, int qtdeArmas, String regiao) {
        super(codigo, nome, peso, altura, qtdeArmas, regiao);
    }

    @Override
    int getAtaque() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setAtaque(int ataque) {
        super.setAtaque(50); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    int Atacar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void habilidadeEspecial() {
        // soma 3 ataques
        // ATAQUE FINAL
        
    }


}
