
package abatalhafinal;

public class Trocadores extends Feiticeiros {
    
    //ataque = 20
    
    //habilidade = troca de lugar
        //rebate o ataque para a segunda maldição da fila
        //se não tiver outra maldição faz ataque padrão

    
    //construtor
    public Trocadores(int codigo, String nome, int peso, double altura, int qtdeArmas, String regiao) {
        super(codigo, nome, peso, altura, qtdeArmas, regiao);
    }

    @Override
    int getAtaque() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public void setAtaque(int ataque) {
        super.setAtaque(20); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    int Atacar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    void habilidadeEspecial() {
        //troca de posção na lista
        
    }


}

