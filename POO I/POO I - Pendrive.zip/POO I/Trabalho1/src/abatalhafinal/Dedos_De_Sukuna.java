/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

/**
 *
 * @author layla
 */
public class Dedos_De_Sukuna extends Maldicoes {

    public Dedos_De_Sukuna(int codigo, String nome, int peso, double altura, String obscuro) {
        super(codigo, nome, peso, altura, obscuro);
    }

    @Override
    void habilidadeEspecial() {
        int random = 0;
        int aux;
        switch (random) {
            
            case 1:
                aux = this.energia + 20;
                if (aux > 100) {
                    this.energia = 100;
                }
                break;
                
            case 2:
                
                break;
                
            default:
                break;
        }
       
                
                
        //HABILIDADE 1:
            //Recupera a vida toda se não matar feiticeiro
            /*
            aux = 99 + 20 = 119
            if (aux > 100)
                return life = 100
            */
            
        //HABILIDADE 2:
            //50% de chance de matar feiticeiros
    }
}
