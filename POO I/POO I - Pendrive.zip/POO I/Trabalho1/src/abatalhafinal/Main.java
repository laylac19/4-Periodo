package abatalhafinal;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static List getFeiticeiros(String arquivo) {

        Object Feiticeiros;
        
        int quantidade= -1;

        int codigo;
        
        int qtdeArmas = 0;
        String regiao = null;
        String nome = null;
        int peso = 0;
        double altura = 0;
                
        List wizards = null;

        try (FileReader arq = new FileReader(arquivo)) {

            Scanner linha = new Scanner(arq);

            if (linha.hasNext()) {
                quantidade = linha.nextInt();
                wizards = new ArrayList(quantidade);
            }

            if (quantidade > 0) {
                int count = 0;
                while (linha.hasNext()) {
                    codigo = linha.nextInt();
                    Feiticeiros = null;
                    switch (codigo) {
                        case 1:
                            Feiticeiros = new Trocadores (1, nome, peso, altura, qtdeArmas, regiao);
                            break;
                        case 2:
                            Feiticeiros = new Criadores (2, nome, peso, altura, qtdeArmas, regiao);
                            break;
                        case 3:
                            Feiticeiros = new Armados (3, nome, peso, altura, qtdeArmas, regiao);
                            break;
                        case 4:
                            Feiticeiros = new Devastadores (4, nome, peso, altura, qtdeArmas, regiao);
                            break;
                        default:
                            break;
                    }
                    wizards.add(Feiticeiros);
                    count++;
                }
            }
            arq.close();

        } catch (IOException ex) {
        }
        return wizards;
    }
    
    private static List getMaldicoes(String arquivo) {

        Object Maldicoes;
        
        int quantidade = -1;

        int codigo;
        String nome = null;
        int peso = 0;
        double altura = 0;
        String humano = null;
        
        List curses = null;

        try (FileReader arq = new FileReader(arquivo)) {

            Scanner linha = new Scanner(arq);

            if (linha.hasNext()) {
                quantidade = linha.nextInt();
                curses = new ArrayList(quantidade);
            }

            if (quantidade > 0) {
                int count = 0;
                while (linha.hasNext()) {
                    codigo = linha.nextInt();
                    Maldicoes = null;
                    switch (codigo) {
                        case 1:
                            Maldicoes = new Basicas (1, nome, peso, altura, humano);
                            break;
                        case 2:
                            Maldicoes = new Copiadores (2, nome, peso, altura, humano);
                            break;
                        case 3:
                            Maldicoes = new Resistentes (3, nome, peso, altura, humano);
                            break;
                        case 4:
                            Maldicoes = new Dedos_De_Sukuna (4, nome, peso, altura, humano);
                            break;
                        case 5:
                            Maldicoes = new Sukunas (5, nome, peso, altura, humano);
                            break;
                        default:
                            break;
                    }
                    curses.add(Maldicoes);
                    count++;
                }
            }
            arq.close();
        } catch (IOException ex) {
        }
        return curses;
    }
    
    public static void main(String[] args) {
      	String arq_feiticeiros = "Feiticeiros.txt";
        String arq_maldicoes = "Maldicoes.txt";
        
        List feiticeiros = getFeiticeiros(arq_feiticeiros);
        List maldicoes = getMaldicoes(arq_maldicoes);
        
        System.out.println(feiticeiros);
        System.out.println(maldicoes);
    } 
}
