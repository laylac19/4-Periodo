/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

//Principal das Maldições
public abstract class Maldicoes extends Ser {
    protected int ataque;
    protected String obscuro; //Nome indivíduo responsável pala criação da maldição
    protected int qtdeArmas;

    //construtor
    public Maldicoes(int ataque, String obscuro, int qtdeArmas, String nome, int peso, double altura, int energia) {
        super(nome, peso, altura, energia);
        this.ataque = ataque;
        this.obscuro = obscuro;
        this.qtdeArmas = qtdeArmas;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public String getObscuro() {
        return obscuro;
    }

    public void setObscuro(String obscuro) {
        this.obscuro = obscuro;
    }

    public int getQtdeArmas() {
        return qtdeArmas;
    }

    public void setQtdeArmas(int qtdeArmas) {
        this.qtdeArmas = qtdeArmas;
    }
    
    public abstract void atacar();
}

