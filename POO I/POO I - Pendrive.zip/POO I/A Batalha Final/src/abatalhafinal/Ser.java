/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

//colocar como prote
public abstract class Ser { //o qualificador define a visibilidade 
    //todo ser tem essas características
    protected int codigo;
    protected String nome;
    protected int peso;
    protected double altura;
    protected int energia; //life
    
    //construtor
    public Ser(String nome, int peso, double altura, int energia) {
        this.nome = nome;
        this.peso = peso;
        this.altura = altura;
        this.energia = energia;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public int getEnergia() {
        return energia;
    }

    public void setEnergia(int energia) {
        this.energia = energia;
    }
}

    
    