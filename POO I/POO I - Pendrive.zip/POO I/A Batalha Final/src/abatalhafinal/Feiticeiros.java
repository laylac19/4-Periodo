package abatalhafinal;

public abstract class Feiticeiros extends Ser {
    protected int ataque;
    protected int qtdeArmas;
    protected String regiao;

    //construtor
    public Feiticeiros(int ataque, int qtdeArmas, String regiao, String nome, int peso, double altura, int energia) {
        super(nome, peso, altura, energia);
        this.ataque = ataque;
        this.qtdeArmas = qtdeArmas;
        this.regiao = regiao;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getQtdeArmas() {
        return qtdeArmas;
    }

    public void setQtdeArmas(int qtdeArmas) {
        this.qtdeArmas = qtdeArmas;
    }

    public String getRegiao() {
        return regiao;
    }

    public void setRegiao(String regiao) {
        this.regiao = regiao;
    }   
    
    public abstract void atacar();
}