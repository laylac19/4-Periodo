/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package execoesaula;

/**
 *
 * @author 2020122760102
 */
public class ExecoesAula {

    public static void main(String[] args) throws Exception {
        /*
        try {
            int a = Integer.parseInt(args[0]);
            int b = Integer.parseInt(args[1]);
            System.out.println("Divisao = " + (a / b));
            
        } 
        catch (ArithmeticException erro) {
            System.out.println("Erro de divisão por zero");
        }
        catch ( ArrayIndexOutOfBoundsException erro ) {
            System.out.println("Numero de argumentos invalido");
        } 
        catch (NumberFormatException erro) {
            System.out.println("Digite apenas numeros inteiros");
        } 
        finally {
            System.out.println("Final da execução !");
        }
        
        try {
            int a = 1;
            System.out.println("Como aprender ");
            if (a == 1) {
                throw new Exception("Minha excecao");
            }
            System.out.println("será que chega aqui ");
        }
        catch ( Exception erro) {
            System.out.println(" a linguagem Java");
        }

        int x = 10, y = 0, z = 0;
        try {
            // gera uma exceção aritmética de
            // divisão por zero
            z = x / y;
            z = 0;
        } catch (Exception erro) {
            // mostra a mensagem de erro
            System.out.println(erro.getMessage());
            // mostra a exceção e a linha onde
            // ocorreu o erro
        }
*/
        
        
    }    
}
