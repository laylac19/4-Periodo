/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operador3pontos;

public class Operador3Pontos {
    private static String valores[];
    
    public static void lerValores(String... valores) {
        Operador3Pontos.valores = valores;
    }
    
    public static void mostrarValores() {
        for(String s: Operador3Pontos.valores) {
            System.out.println(s);
        }
    }
    
    public static void lerValores(String valor, int... numeros) {
        Operador3Pontos.valores = new String[numeros.length+1];
        Operador3Pontos.valores[0] = valor;
        
        for(int i = 0; i < numeros.length; i++) {
            Operador3Pontos.valores[i+1] = String.valueOf(numeros[i]);
        }
    }
    
    public static void main(String[] args) {
      lerValores ("a", "b", "c", "d");
      mostrarValores();
      lerValores ("Teste", 1, 2, 3, 4);
      mostrarValores();
    }
    
}
