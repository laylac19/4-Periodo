package trabalho.de.pooi;

public abstract class Artesanal extends Arma {

    public Artesanal(int serial, int pontuacao) {
        super(serial, pontuacao);
    }
    
}