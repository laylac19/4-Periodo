package trabalho.de.pooi;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Estoque {

    private int madeira;
    private int aco;
    private int ferro;
    private int aluminio;
    private int chumbo;
    private int cobre;
    private int ouro;
    private int prata;
    private int couro;
    private int pedra;

    public int getMadeira() {
        return madeira;
    }

    public void setMadeira(int madeira) {
        this.madeira = madeira;
    }

    public int getAco() {
        return aco;
    }

    public void setAco(int aco) {
        this.aco = aco;
    }

    public int getFerro() {
        return ferro;
    }

    public void setFerro(int ferro) {
        this.ferro = ferro;
    }

    public int getAluminio() {
        return aluminio;
    }

    public void setAluminio(int aluminio) {
        this.aluminio = aluminio;
    }

    public int getChumbo() {
        return chumbo;
    }

    public void setChumbo(int chumbo) {
        this.chumbo = chumbo;
    }

    public int getCobre() {
        return cobre;
    }

    public void setCobre(int cobre) {
        this.cobre = cobre;
    }

    public int getOuro() {
        return ouro;
    }

    public void setOuro(int ouro) {
        this.ouro = ouro;
    }

    public int getPrata() {
        return prata;
    }

    public void setPrata(int prata) {
        this.prata = prata;
    }

    public int getCouro() {
        return couro;
    }

    public void setCouro(int couro) {
        this.couro = couro;
    }

    public int getPedra() {
        return pedra;
    }

    public void setPedra(int pedra) {
        this.pedra = pedra;
    }

    private void setMaterial(String material, int quantidade) {

        if (quantidade >= 0) {

            switch (material) {

                case "Madeira":
                    this.madeira = quantidade;
                    break;
                case "Aco":
                    this.aco = quantidade;
                    break;
                case "Ferro":
                    this.ferro = quantidade;
                    break;
                case "Aluminio":
                    this.aluminio = quantidade;
                    break;
                case "Chumbo":
                    this.chumbo = quantidade;
                    break;
                case "Cobre":
                    this.cobre = quantidade;
                    break;
                case "Ouro":
                    this.ouro = quantidade;
                    break;
                case "Prata":
                    this.prata = quantidade;
                    break;
                case "Couro":
                    this.couro = quantidade;
                    break;
                case "Pedra":
                    this.pedra = quantidade;
                    break;
                default:
                    
                    break;
            }
        } else {

        }

    }

    public Estoque(String caminho) {
        
        try (FileReader arquivo = new FileReader(caminho)) {
            String material;
            int quantidade;
            Scanner linha = new Scanner(arquivo);
            while (linha.hasNext()) {
                material = linha.next();
                quantidade = linha.nextInt();
                setMaterial(material, quantidade);
            }
            arquivo.close();
            
        }catch (IOException ex) {
            Logger.getLogger(Estoque.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
