package trabalho.de.pooi;

public class Lanca_Foguetes_OnOn extends Profissional {
    
    private boolean acessorio;

    public Lanca_Foguetes_OnOn(int serial, int pontuacao, int calibre, boolean acessorio) {
        
        //super(serial, 5, 150, 1000);
        super(serial, pontuacao, calibre);
        
        this.acessorio = acessorio;
        this.aco = 1000;
        this.ferro = 1000;
        this.aluminio = 400;
        this.chumbo = 20;
        this.ouro = 10;
        
        if(this.acessorio){
            this.prata = 500;
            this.pontuacao = 300;
        }
        
    }

    public boolean getAcessorio() {
        return acessorio;
    }
    
}