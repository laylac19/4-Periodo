package trabalho.de.pooi;

public abstract class Profissional extends Arma {
    
    private int calibre;

    public Profissional(int serial, int pontuacao, int calibre) {
        super(serial, pontuacao);
        this.calibre = calibre;
    }

    public int getCalibre() {
        return calibre;
    }
    
}