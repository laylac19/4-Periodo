package trabalho.de.pooi;

public class Bazuka_Zonka extends Profissional {

    private int bocal;

    public Bazuka_Zonka(int serial, int pontuacao, int calibre, int bocal) {

        //super(serial, 5, 200, 1000);
        super(serial, pontuacao, calibre);
        
        this.bocal = bocal;
        this.aco = 1000;
        this.ferro = 1000;
        this.aluminio = 500;
        this.chumbo = 20;
        this.prata = 200;
        this.pedra = 100;

        if (this.bocal > 0) {
            this.aco += bocal * 200;
            this.ouro += bocal * 100;
            this.pontuacao += bocal * 100;
        }

    }

    public int getBocal() {
        return bocal;
    }
}
