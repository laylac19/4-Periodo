package trabalho.de.pooi;

public class Pistola_Canked extends Profissional {
    
    private boolean acessorio;

    public Pistola_Canked(int serial, int pontuacao, int calibre, boolean acessorio) {
        
        //super(serial, 2, 5, 40);
        super(serial, pontuacao, calibre);
        
        this.acessorio = acessorio;
        this.madeira = 50;
        this.aco = 100;
        this.ferro = 50;
        this.chumbo = 20;
        this.cobre = 10;
        this.ouro = 30;
        this.prata = 20;
        
        if(this.acessorio){
            this.prata = 80;
            this.pontuacao = 15;
        }
        
    }
    
}