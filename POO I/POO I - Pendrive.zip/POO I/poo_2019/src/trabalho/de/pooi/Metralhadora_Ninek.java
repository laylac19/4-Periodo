package trabalho.de.pooi;

public class Metralhadora_Ninek extends Profissional {

    public Metralhadora_Ninek(int serial, int pontuacao, int calibre) {
        
        //super(serial, 3, 20, 80);
        super(serial, pontuacao, calibre);
        
        this.madeira = 200;
        this.aco = 200;
        this.ferro = 200;
        this.ouro = 10;
        this.prata = 10;
        
    }
    
}