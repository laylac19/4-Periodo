package trabalho.de.pooi;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

    public class TrabalhoDePOOI {

    private static List getArmasNigeria(String arquivo) {

        int quantidade = -1;
        Object arma;
        int codigo;
        int serial;
        boolean acessorio;
        int bocal;
        List armas = null;

        try (FileReader arq = new FileReader(arquivo)) {

            Scanner linha = new Scanner(arq);

            if (linha.hasNext()) {
                quantidade = linha.nextInt();
                armas = new ArrayList(quantidade);
            }

            if (quantidade > 0) {
                int count = 0;
                while (linha.hasNext()) {
                    codigo = linha.nextInt();
                    serial = linha.nextInt();
                    arma = null;
                    switch (codigo) {
                        case 1:
                            arma = new Estilingue_de_Suri(serial, 1);

                            break;
                        case 2:
                            acessorio = linha.nextBoolean();
                            arma = new Pistola_Canked(serial, 5, 40, acessorio);
                            break;
                        case 3:
                            arma = new Metralhadora_Ninek(serial, 20, 80);
                            break;
                        case 4:
                            arma = new Fuzil_K777(serial, 50, 100);
                            break;
                        case 5:
                            bocal = linha.nextInt();
                            arma = new Bazuka_Zonka(serial, 200, 1000, bocal);
                            break;
                        default:
                            break;
                    }

                    armas.add(arma);
                    count++;
                }
            }

            arq.close();

        } catch (IOException ex) {
            Logger.getLogger(Estoque.class.getName()).log(Level.SEVERE, null, ex);
        }

        return armas;
    }

    private static List getArmasBokoHaram(String arquivo) {

        int quantidade = 0;
        Object arma;
        int codigo;
        int serial;
        boolean acessorio;
        int bocal = -1;
        List armas = null;

        try (FileReader arq = new FileReader(arquivo)) {

            Scanner linha = new Scanner(arq);

            if (linha.hasNext()) {
                quantidade = linha.nextInt();
                armas = new ArrayList(quantidade);
            }

            if (quantidade > 0) {
                int count = 0;
                while (linha.hasNext()) {
                    codigo = linha.nextInt();
                    serial = linha.nextInt();
                    arma = null;
                    switch (codigo) {
                        case 1:
                            acessorio = linha.nextBoolean();
                            arma = new Zarabatana_Longin(serial, 2, acessorio);
                            break;
                        case 2:
                            acessorio = linha.nextBoolean();
                            arma = new Lanca_Foral(serial, 1, acessorio);
                            break;
                        case 3:
                            arma = new Metralhadora_HamHam(serial, 10, 80);
                            break;
                        case 4:
                            arma = new Lanca_Chamas_Mirak(serial, 40, 50);
                            break;
                        case 5:
                            acessorio = linha.nextBoolean();
                            arma = new Lanca_Foguetes_OnOn(serial, 150, 1000, acessorio);
                            break;
                        default:
                            break;
                    }

                    armas.add(arma);
                    count++;
                }
            }

            arq.close();

        } catch (IOException ex) {
            Logger.getLogger(Estoque.class.getName()).log(Level.SEVERE, null, ex);
        }

        return armas;
    }

    private static int armasArtesanaisNigeria(List armas) {
        int total = 0;
        Object arma;
        String nomeClasse;
        for (int i = 0; i < armas.size(); i++) {
            arma = armas.get(i);
            nomeClasse = arma.getClass().getSimpleName();
            switch (nomeClasse) {
                case "Estilingue_de_Suri":
                    total++;
                    break;
                default:
                    break;
            }
        }

        if (total > 0) {
            System.out.println("O exército nigeriano produz " + total + " arma artesanal por dia.");
        }

        return total;
    }

    private static int armasArtesanaisBokoHaram(List armas) {
        int total = 0;
        Object arma;
        String nomeClasse;
        for (int i = 0; i < armas.size(); i++) {
            arma = armas.get(i);
            nomeClasse = arma.getClass().getSimpleName();
            switch (nomeClasse) {
                case "Zarabatana_Longin":
                    total++;
                    break;
                case "Lanca_Foral":
                    total++;
                    break;
                default:
                    break;
            }
        }

        if (total > 0) {
            System.out.println("O Boko Haram produz " + total + " arma artesanal por dia.");
        }

        return total;
    }

    private static void bocalBazuka_Zonka(List armas) {
        int maiorBocal = 0;
        List<Bazuka_Zonka> bazuka = new ArrayList(armas.size());
        Bazuka_Zonka arma;
        Object atual;
        String nomeClasse;
        for (int i = 0; i < armas.size(); i++) {
            atual = armas.get(i);
            nomeClasse = atual.getClass().getSimpleName();
            switch (nomeClasse) {
                case "Bazuka_Zonka":
                    arma = (Bazuka_Zonka) atual;

                    if (maiorBocal < arma.getBocal()) {
                        maiorBocal = arma.getBocal();
                        if (!(bazuka.isEmpty())) {
                            bazuka.clear();
                        }
                        bazuka.add(arma);
                    } else if (maiorBocal == arma.getBocal()) {
                        bazuka.add(arma);
                    }

                    break;
                default:
                    break;
            }
        }

        if (!(bazuka.isEmpty())) {
            if (bazuka.size() == 1) {
                System.out.println("A Bazuka Zonka de serial " + bazuka.get(0).getSerial() + " é a que possui mais bocais (" + bazuka.get(0).getBocal() + " bocais).");
            } else {
                System.out.println("EMPATE: ");
                for (int i = 0; i < bazuka.size() - 1; i++) {
                    System.out.print(bazuka.get(i).getSerial() + ", ");
                }
                System.out.print(bazuka.get(bazuka.size() - 1).getSerial() + ".");
            }
        } else {
            System.out.println("Não há Bazuka Zonka.");
        }
    }

    private static void qtdLancaFoguetesEspeciais(List armas) {
        List<Lanca_Foguetes_OnOn> normais = new ArrayList(armas.size());
        List<Lanca_Foguetes_OnOn> especiais = new ArrayList(armas.size());
        Lanca_Foguetes_OnOn arma;
        Object atual;
        String nomeClasse;

        for (int i = 0; i < armas.size(); i++) {
            atual = armas.get(i);
            nomeClasse = atual.getClass().getSimpleName();
            switch (nomeClasse) {
                case "Lanca_Foguetes_OnOn":
                    arma = (Lanca_Foguetes_OnOn) atual;
                    if (!(arma.getAcessorio())) {
                        normais.add(arma);
                    } else {
                        especiais.add(arma);
                    }
                    break;
                default:
                    break;
            }
        }

        if (normais.size() < especiais.size()) {
            System.out.println("SIM.");
        } else if (normais.size() > especiais.size()) {
            System.out.println("NÃO.");
        } else {
            System.out.println("EMPATE.");
        }
    }

    private static void calibreMaior100(List nigeria, List boko_haram) {

        ArrayList maior100 = new ArrayList();

        Object atual;
        String nomeClasse;

        for (int i = 0; i < nigeria.size(); i++) {
            atual = nigeria.get(i);
            nomeClasse = atual.getClass().getGenericSuperclass().getTypeName();
            switch (nomeClasse) {
                case "trabalho.de.pooi.Profissional":
                    if (((Profissional) atual).getCalibre() > 100) {
                        maior100.add(((Profissional) atual).getSerial());
                    }
                    
                    break;
                default:
                    break;
            }
        }

        for (int i = 0; i < boko_haram.size(); i++) {
            atual = boko_haram.get(i);
            nomeClasse = atual.getClass().getGenericSuperclass().getTypeName();
            switch (nomeClasse) {
                case "trabalho.de.pooi.Profissional":
                    if (((Profissional) atual).getCalibre() > 100) {
                        maior100.add(((Profissional) atual).getSerial());
                    }

                    break;
                default:
                    break;
            }
        }

        System.out.print("As armas com calibre maior que 100 são: ");

        for (int i = 0; i < maior100.size() - 1; i++) {
            System.out.print(maior100.get(i) + ", ");
        }

        System.out.println(maior100.get(maior100.size() - 1) + ".");

    }
    
    public static int diasEstoque(Estoque estoque, List armas, String nome) {

        int pontosTotal = 0, parar = 0, dias = 0;
        Object arma;
        boolean continuar = true;
        
        while(parar < armas.size()){
            parar = 0;
            for (int i = 0; (i < armas.size()) && (parar < armas.size()); i++) {
                
                arma = armas.get(i);
                continuar = ((Arma) arma).estoqueDec(estoque);
                
                if (continuar == true) {
                    pontosTotal += ((Arma) arma).getPontuacao();
                    if(i + 1 == armas.size()){
                        dias++;
                    }
                } else {
                    parar++;
                }
            }
        }
        
        System.out.println("O " + nome + " chegou à pontuação de " + pontosTotal + ".");
        
        return dias;

    }

    public static void main(String[] args) {
        
        String arq_estoque_nigeria = "C:\\Users\\2018122760119\\Downloads\\estoque_exercito_nigeriano.txt";
        String arq_armas_nigeria = "C:\\Users\\2018122760119\\Downloads\\armas_exercito_nigeriano.txt";
        String arq_estoque_boko_haram = "C:\\Users\\2018122760119\\Downloads\\estoque_boko_haram.txt";
        String arq_armas_boko_haram = "C:\\Users\\2018122760119\\Downloads\\armas_boko_haram.txt";
        
        Estoque estoque_nigeria = new Estoque(arq_estoque_nigeria);
        Estoque estoque_boko_haram = new Estoque(arq_estoque_boko_haram);
        
        List armas_nigeria = getArmasNigeria(arq_armas_nigeria);
        List armas_boko_haram = getArmasBokoHaram(arq_armas_boko_haram);
        
        int artesanalNigeria = armasArtesanaisNigeria(armas_nigeria);
        int artesanalBokoHaram = armasArtesanaisBokoHaram(armas_boko_haram);
        
        if ((artesanalNigeria + artesanalBokoHaram) > 0) {
            System.out.println("O total de armas artesanais produzidas é " + (artesanalNigeria + artesanalBokoHaram) + ".");
        }
        
        bocalBazuka_Zonka(armas_nigeria);
        qtdLancaFoguetesEspeciais(armas_boko_haram);
        calibreMaior100(armas_nigeria, armas_boko_haram);
        int bokoDias = diasEstoque(estoque_boko_haram, armas_boko_haram, "Boko Haram");
        int nigerDias = diasEstoque(estoque_nigeria, armas_nigeria, "exército nigeriano");
        System.out.println("O Boko Haram possui estoque para " + bokoDias + " dias.");
        System.out.println("O exército nigeriano possui estoque para " + nigerDias + " dias.");
        
    }
}
