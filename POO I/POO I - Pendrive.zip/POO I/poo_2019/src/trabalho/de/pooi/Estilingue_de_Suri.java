package trabalho.de.pooi;

public class Estilingue_de_Suri extends Artesanal {

    public Estilingue_de_Suri(int serial, int pontuacao) {
        
        //super(serial, 1, 1);
        super(serial, pontuacao);
        
        this.madeira = 100;
        this.aluminio = 50;
        this.couro = 30;
        this.pedra = 100;
        
    }
    
}