package trabalho.de.pooi;

public class Zarabatana_Longin extends Artesanal {
    
    private boolean acessorio;

    public Zarabatana_Longin(int serial, int pontuacao, boolean acessorio) {
        
        //super(serial, 1, 2);
        super(serial, pontuacao);
        
        this.acessorio = acessorio;
        this.madeira = 300;
        this.pedra = 20;
        
    }
    
}