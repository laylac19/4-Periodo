package trabalho.de.pooi;

public abstract class Arma {
    
    protected int serial;
    //private final int codigo;
    protected int pontuacao;
    
    protected int madeira = 0;
    protected int aco = 0;
    protected int ferro = 0;
    protected int aluminio = 0;
    protected int chumbo = 0;
    protected int cobre = 0;
    protected int ouro = 0;
    protected int prata = 0;
    protected int couro = 0;
    protected int pedra = 0;
    
    public Arma(int serial, int pontuacao) {
        
        this.serial = serial;
        this.pontuacao = pontuacao;
        
    }
    
    private static boolean validarDec(int estoque, int valor) {
        return estoque >= valor;
    }
    
    public boolean estoqueDec(Estoque estoque){
        
        /*System.out.println("MADEIRA: " + estoque.getMadeira() + "\tCUSTO: " + this.madeira);
        System.out.println("AÇO: " + estoque.getAco() + "\tCUSTO: " + this.aco);
        System.out.println("FERRO: " + estoque.getFerro() + "\tCUSTO: " + this.ferro);
        System.out.println("ALUMÍNIO: " + estoque.getAluminio() + "\tCUSTO: " + this.aluminio);
        System.out.println("CHUMBO: " + estoque.getChumbo() + "\tCUSTO: " + this.chumbo);
        System.out.println("COBRE: " + estoque.getCobre() + "\tCUSTO: " + this.cobre);
        System.out.println("OURO: " + estoque.getOuro() + "\tCUSTO: " + this.ouro);
        System.out.println("PRATA: " + estoque.getPrata() + "\tCUSTO: " + this.prata);
        System.out.println("COURO: " + estoque.getCouro() + "\tCUSTO: " + this.couro);
        System.out.println("PEDRA: " + estoque.getPedra() + "\tCUSTO: " + this.pedra);*/
        
        if (validarDec(estoque.getMadeira(), this.madeira) && 
            validarDec(estoque.getAco(), this.aco) &&
            validarDec(estoque.getFerro(), this.ferro) && 
            validarDec(estoque.getAluminio(), this.aluminio) &&
            validarDec(estoque.getChumbo(), this.chumbo) &&
            validarDec(estoque.getCobre(), this.cobre) &&
            validarDec(estoque.getOuro(), this.ouro) &&
            validarDec(estoque.getPrata(), this.prata) &&
            validarDec(estoque.getCouro(), this.couro) &&
            validarDec(estoque.getPedra(), this.pedra)){
            //System.out.println("ENTROU AQUI.");
            estoque.setMadeira(estoque.getMadeira() - this.madeira);
            estoque.setAco(estoque.getAco() - this.aco);
            estoque.setFerro(estoque.getFerro() - this.ferro);
            estoque.setAluminio(estoque.getAluminio() - this.aluminio);
            estoque.setChumbo(estoque.getChumbo() - this.chumbo);
            estoque.setCobre(estoque.getCobre() - this.cobre);
            estoque.setOuro(estoque.getOuro() - this.ouro);
            estoque.setPrata(estoque.getPrata() - this.prata);
            estoque.setCouro(estoque.getCouro() - this.couro);
            estoque.setPedra(estoque.getPedra() - this.pedra);
            
            return true;
            
        }
        
        return false;
        
    }

    public int getSerial() {
        return serial;
    }

    public int getPontuacao() {
        return pontuacao;
    }
    
}