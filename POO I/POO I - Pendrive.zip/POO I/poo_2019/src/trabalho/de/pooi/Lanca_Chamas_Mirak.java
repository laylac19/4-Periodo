package trabalho.de.pooi;

public class Lanca_Chamas_Mirak extends Profissional {

    public Lanca_Chamas_Mirak(int serial, int pontuacao, int calibre) {
        
        //super(serial, 4, 40, 50);
        super(serial, pontuacao, calibre);
        
        this.madeira = 500;
        this.aco = 20;
        this.ferro = 20;
        this.aluminio = 20;
        this.chumbo = 20;
        this.cobre = 10;
        this.ouro = 10;
        this.prata = 10;
        this.pedra = 20;
        
    }
    
}