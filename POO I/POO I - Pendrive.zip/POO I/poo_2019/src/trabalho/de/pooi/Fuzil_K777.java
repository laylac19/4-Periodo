package trabalho.de.pooi;

public class Fuzil_K777 extends Profissional {

    public Fuzil_K777(int serial, int pontuacao, int calibre) {
        
        //super(serial, 4, 50, 100);
        super(serial, pontuacao, calibre);
        
        this.ferro = 800;
        this.aluminio = 20;
        this.chumbo = 20;
        this.cobre = 20;
        this.ouro = 20;
        this.prata = 20;
        this.pedra = 50;
        
    }
    
}