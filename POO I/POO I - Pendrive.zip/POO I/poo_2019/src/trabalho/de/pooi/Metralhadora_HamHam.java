package trabalho.de.pooi;

public class Metralhadora_HamHam extends Profissional {

    public Metralhadora_HamHam(int serial, int pontuacao, int calibre) {
        
        //super(serial, 3, 10, 80);
        super(serial, pontuacao, calibre);
        
        this.madeira = 20;
        this.aco = 50;
        this.ferro = 50;
        this.aluminio = 50;
        this.chumbo = 50;
        this.couro = 20;
        this.pedra = 20;
        
    }
    
}