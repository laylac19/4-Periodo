package trabalho.de.pooi;

public class Lanca_Foral extends Artesanal {
    
    private boolean acessorio;

    public Lanca_Foral(int serial, int pontuacao, boolean acessorio) {
        
        //super(serial, 2, 1);
        super(serial, pontuacao);
        
        this.acessorio = acessorio;
        this.madeira = 100;
        this.ferro = 100;
        this.pedra = 200;
        
    }
    
}