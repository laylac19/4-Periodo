/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

/**
 *
 * @author 2020122760102
 */

//Comparable 
public class Pessoa implements Comparable {

    private String nome;
    private int idade;

    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
    
    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
    
    @Override
    public String toString() {
        return "Pessoa{ " + "nome = " + nome + " idade = " + idade + " }";
    }
    
    public int compardorIdade(Object o) {
        Pessoa outro = (Pessoa) o;
        // O objeto corrente tem maior idade
        if (this.idade > outro.idade) {
            return 1;
        } // as idades são iguais
        else if (this.idade == outro.idade) {
            return 0;
        } // O objeto forneceido como parâmetro tem maior idade
        else {
            return -1;
        }
    }

    public int compareTo(Object o) {
        Pessoa outro = (Pessoa) o;
        int compareTo;
        
        //crescente 
        return compareTo = (this.nome.compareTo(outro.nome));
        
        //decrescente 
        //return compareTo = (this.nome.compareTo(outro.nome)) * -1;
    }
}





