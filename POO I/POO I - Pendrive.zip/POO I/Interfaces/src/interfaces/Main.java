/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author 2020122760102
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ArrayList<Pessoa> pessoas = new ArrayList(10);
        Pessoa p;
        
        pessoas.add(new Pessoa("Pedro", 10));
        pessoas.add(new Pessoa("Medro", 5));
        pessoas.add(new Pessoa("Ane", 20));
        pessoas.add(new Pessoa("Zana", 30));
        pessoas.add(new Pessoa("Tina", 15));
        
        int op;
        Scanner num = Scanner(System.in);
        
        

        Collections.sort(pessoas, (Pessoa o1, Pessoa o2) -> o1.getNome().compareTo(o2.getNome()));
        Iterator<Pessoa> it = pessoas.iterator();
        while (it.hasNext()) {
            p = it.next();
            System.out.println(p);
        }
    }
}
