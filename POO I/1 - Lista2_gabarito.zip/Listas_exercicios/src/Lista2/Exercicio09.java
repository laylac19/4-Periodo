/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double a, b, c, delta, x1, x2;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("\n\tInforme o valor do coeficiente A: ");
	a = entrada.nextDouble();

	if ( a == 0 ) {
            System.out.println("\n\tIsso nao e' uma equacao de segundo grau!\n\n");
	}
        else {
            System.out.print("\n\tInforme o valor do coeficiente B: ");
            b = entrada.nextDouble();

            System.out.print("\n\tInforme o valor do coeficiente C: ");
            c = entrada.nextDouble();

            // Calcular o delta
            delta = b * b - 4 * a * c;

            if ( delta < 0 ) {
                System.out.println("\n\tEssa equacao nao possui raízes!");
            }
            else {
                x1 = ( -1 * b + Math.sqrt(delta) ) / (2 * a) ;
                x2 = ( -1 * b - Math.sqrt(delta) ) / (2 * a) ;
                System.out.println("\n\tX1 = " + x1 + "\tX2 = " + x2);
            }
        }
    }
    
}
