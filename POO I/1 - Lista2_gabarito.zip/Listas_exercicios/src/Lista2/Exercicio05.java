/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int idade;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe sua idade: ");
	idade = entrada.nextInt();

	// verifica em qual categoria encaixa a idade da pessoa
	if ( idade <= 0 ) {
            System.out.println("A idade digitada eh invalida!");
	}
	else if ( idade < 18 ) {
            System.out.println("Voce eh menor de idade!");
	}
	else if ( idade < 65 ) {
            System.out.println("Voce eh maior de idade!");			
	}
	else {
            System.out.println("Voce eh uma pessoa idosa!");
	}
    }
    
}
