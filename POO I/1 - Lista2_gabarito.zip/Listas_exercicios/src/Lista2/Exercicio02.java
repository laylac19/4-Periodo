/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double num;
        
        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe um numero: ");
	num = entrada.nextDouble();

	// verifica o valor de num e apresenta a mensagem relacionada
	if(num >= 0) {
            System.out.println(num + " eh positivo ou igual a zero, entao sua raiz quadrada eh " + Math.sqrt(num) );
	}
	else {
            System.out.println(num + " eh negativo, entao o seu quadrado eh " + Math.pow(num,2) );
	}
    }
    
}
