/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int dia;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("\n\tInforme um numero inteiro: ");
	dia = entrada.nextInt();

	switch(dia){
            case 1:
                System.out.println("\n\tVoce digitou o numero correspondente ao Domingo.\n\n");
                break;
            case 2:
		System.out.println("\n\tVoce digitou o numero correspondente a Segunda-feira.\n\n");
                break;
            case 3:
		System.out.println("\n\tVoce digitou o numero correspondente a Terca-feira.\n\n");
                break;
            case 4:
		System.out.println("\n\tVoce digitou o numero correspondente a Quarta-feira.\n\n");
                break;
            case 5:
		System.out.println("\n\tVoce digitou o numero correspondente a Quinta-feira.\n\n");
                break;
            case 6:
		System.out.println("\n\tVoce digitou o numero correspondente a Sexta-feira.\n\n");
                break;
            case 7:
		System.out.println("\n\tVoce digitou o numero correspondente ao sabado.\n\n");
                break;
            default:
            	System.out.println("\n\tVoce digitou um numero que nao corresponde a um dia da semana.\n\n");
                break;
	}
    }
    
}
