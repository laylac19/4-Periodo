/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.text.NumberFormat;
import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int codigo, qtde;
	double preco, totalSem, totalDesc, desconto, porc;
        preco = 0.0;
        
        Scanner entrada = new Scanner(System.in);        

	System.out.print("\n\tInforme o codigo do produto: ");
	codigo = entrada.nextInt();

	if ( codigo < 1 || codigo > 40) {
            System.out.println("\n\tCodigo invalido!");
            System.exit(0);    // Para não continuar a execucao
	}
	else if ( codigo <= 10 ) {
            preco = 10.00;
        }
        else if ( codigo <= 20) {
            preco = 15.00;
        }
        else if ( codigo <= 30) {
            preco = 20.00;
        }
        else {
            preco = 30.00;
        }

        System.out.print("\n\tInforme a quantidade do produto: ");
        qtde = entrada.nextInt();
        if ( qtde <= 0 ) {
            System.out.println("\n\tQuantidade invalida!\n\n");
            System.exit(0);    // Para n�o continuar a execucao
        }

        // Calculo do total a pagar SEM o desconto
        totalSem = preco * qtde;

        if ( totalSem <= 250 ) {
            porc = 0.05;
        }
        else if ( totalSem <= 500 ) {
            porc = 0.10;
        }
        else {
            porc = 0.15;
        }

        // Calculo do total a pagar COM o desconto
        desconto = totalSem * porc;
        totalDesc = totalSem - desconto;

        // Impressao dos resultados
        NumberFormat formato = NumberFormat.getCurrencyInstance();
        
        System.out.println ("\tPreco do produto:   \t" + formato.format(preco) );
        System.out.println ("\tTotal sem desconto: \t" + formato.format(totalSem) );
        System.out.println ("\tDesconto:          \t-" + formato.format(desconto) );
        System.out.println ("\t              \t---------------------");
        System.out.println ("\tTotal a pagar:      \t" + formato.format(totalDesc) );
    }
    
}
