/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package condicionais;
public class Condicionais02 {
    public static void main(String[] args) {
        if ( args.length == 1)
        {
            int x;
            x  = Integer.parseInt(args[0]);
            switch ( x )
            {
                case 10: System.out.println("dez"); break;
                case 20: System.out.println("vinte"); break;
                case 30: System.out.println("trinta"); break;
                case 40: System.out.println("quarenta"); break;
                case 50: System.out.println("cinquenta"); break;
                case 60: System.out.println("sessenta"); break;
                case 70: System.out.println("setenta"); break;
                case 80: System.out.println("oitenta"); break;
                case 90: System.out.println("noventa"); break;
                case 100: System.out.println("cem"); break;
                default: System.out.println("Numero desconhecido"); 
            }
        }
        else
            System.out.println("Numero de argumentos invalido");
    }
}
