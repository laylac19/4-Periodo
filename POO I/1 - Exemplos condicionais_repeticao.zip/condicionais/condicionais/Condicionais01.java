/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package condicionais;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Condicionais01 {
    public static void main(String[] args) throws IOException {
        try
        {
            System.out.println("Entre com a nota: ");
            BufferedReader dado = new BufferedReader(new InputStreamReader(System.in));
            String s = dado.readLine();
            double nota = Float.parseFloat(s);
 
            if ( nota <= 100 && nota >= 0)
                System.out.println("Nota = " + nota + " - valor valido");
            else
                System.out.println("Nota = " + nota + " - valor invalido");
        }
        catch ( NumberFormatException erro)
        {
            System.out.println("Digite apenas valores numericos");
        }
    }
}
