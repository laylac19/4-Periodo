/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package repeticoes;
public class Repeticoes02 {
    public static void main(String[] args) {
        int a;
        try
        {
            a = Integer.parseInt(args[0]);
            while ( a >= 0 )
            {
                System.out.println(" " + a);
                a--;
            }
            System.out.println("Fim da primeira contagem");
            System.out.println();
            a = ( -1 ) * Integer.parseInt(args[0]);
            do
            {
                System.out.println(" " + a);
                a++;
                
            } while ( a <= 0 );
            System.out.println("Fim da segunda contagem");
        }
        // se não digitar o argumento
        catch ( ArrayIndexOutOfBoundsException erro )
        {
            System.out.println("Digite um argumento!");
        }
        catch ( NumberFormatException erro)
        {
            System.out.println("Nao foi fornecido um numero inteiro valido!");
        }
    }
}
