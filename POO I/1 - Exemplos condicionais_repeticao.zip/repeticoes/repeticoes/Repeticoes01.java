/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package repeticoes;
public class Repeticoes01 {
    public static void main(String[] args) {
        // TODO code application logic here
        for( int i = 10; i > 0; i--)
        {
            System.out.println(i + " ");
        }
        System.out.println();
        System.out.println("Acabou");
    }
}
