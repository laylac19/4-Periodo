/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista1;

import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int an, a1, n, r;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe o 1o termo: ");
	a1 = entrada.nextInt();

	System.out.print("Informe o numero de termos: ");
	n = entrada.nextInt();

	System.out.print("Informe a razao da P.A.: ");
	r = entrada.nextInt();

	// efetua o cálculo
	an = a1 + (n - 1) * r;

	System.out.println("O valor de AN eh: " + an);
    }
    
}
