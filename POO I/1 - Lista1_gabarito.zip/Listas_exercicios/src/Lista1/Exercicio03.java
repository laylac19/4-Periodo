/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista1;

import java.text.NumberFormat;
import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double valor_produto, novo_valor, desc;
	desc = 0.09;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe o valor do produto: ");
	valor_produto = entrada.nextDouble();

	novo_valor = valor_produto - (valor_produto * desc);

        // Para formatar a saída em forma de moeda, com R$
        // Pega o formato da moeda local
        NumberFormat formatoMoeda = NumberFormat.getCurrencyInstance(); 

	System.out.println("Valor antigo: \t " + formatoMoeda.format(valor_produto));
	System.out.println("Desconto: \t-" + formatoMoeda.format(valor_produto*desc));
	System.out.println("\t      ----------");
	System.out.println("Valor total: \t " + formatoMoeda.format(novo_valor));
    }
    
}
