/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista1;

import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double C, F;

        Scanner entrada = new Scanner(System.in);
         
	System.out.print("Informe a temperatura em graus Centigrados: ");
	C = entrada.nextDouble();

	// faz a conversao para Fahrenheit
	F = (9 * C + 160) / 5;

	System.out.println(C + " graus Celsius corresponde a " + 
                F + " graus Fahrenheit");
    }
    
}
