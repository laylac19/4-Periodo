/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista1;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int qtdeCigarros, anos, dias;
	float tempoPerdido;

        Scanner entrada = new Scanner(System.in);   
        
	System.out.print("Informe quantos cigarros fuma por dia: ");
	qtdeCigarros = entrada.nextInt();

	System.out.print("Informe quantos anos que fuma: ");
	anos = entrada.nextInt();

	// Converter anos em dias. Considerando o ano INTEIRO
	dias = 365 * anos;

	// Calcula quantos minutos foram perdidos
	tempoPerdido = qtdeCigarros * dias * 10;  // em minutos

	// Converter minutos em dias
	tempoPerdido = tempoPerdido / 60 / 24;

        // Para formatar a quantidade de casas decimais
        DecimalFormat formato = new DecimalFormat("#.##"); 
	System.out.println("Foram perdidos: " + formato.format(tempoPerdido) + " dias.");
    }
    
}
