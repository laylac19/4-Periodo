/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista1;

import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int A, B, aux;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe o valor de A: ");
	A = entrada.nextInt();

	System.out.print("Informe o valor de B: ");
	B = entrada.nextInt();

	// mostra os valores antes da troca
	System.out.println("\t====== Antes ======");
	System.out.println("\t A = " + A + " B = " + B);

	// efetua a troca com a variavel auxiliar
	aux = A;
	A = B;
	B = aux;

	// mostra os valores depois da troca
	System.out.println("\t====== Depois ======");
	System.out.println("\t A = " + A + " B = " + B);
    }
    
}
