/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package aspectos_fundamentais;

public class AspectosFundamentais04 {

        public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(args[0]);
        System.out.println(args[1]);
    }
}
