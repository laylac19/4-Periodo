/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package aspectos_fundamentais;
public class AspectosFundamentais03 {
    public static void main(String[] args) {
        // Declaração e inicialização de variáveis
        int x = 10; int y = 3;
        // várias operações com as variáveis
        System.out.println("X = " + x);
        System.out.println("Y = " + y);
        System.out.println("-X = " + (-x));
        System.out.println("X/Y = " + (x/y));
        System.out.println("O resto de X por Y = " + (x%y));
        System.out.println("Inteiro de X por Y = " + (int)(x/y));
        System.out.println("X + 1 = " + (x++));
    }
}
