/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feiticeiros;

import abatalhafinal.Feiticeiros;


public class Armadores extends Feiticeiros {

    public Armadores(int qtdeArmas, String regiao, String nome, double peso, double altura, int energia, int ataque) {
        super(qtdeArmas, regiao, nome, peso, altura, energia, ataque);
    }
    
    
    //ataque: comeca em 5
        //poder do ataque multiplicado pelo numero de armas que consegue carregar
}
