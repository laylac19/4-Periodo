/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feiticeiros;

import abatalhafinal.Feiticeiros;

/**
 *
 * @author 2020122760102
 */
public class Trocadores extends Feiticeiros {

    public Trocadores(int qtdeArmas, String regiao, String nome, double peso, double altura, int energia, int ataque) {
        super(qtdeArmas, regiao, nome, peso, altura, energia, ataque);
    }
    
    //retira 20 da life do outro ser atacado
    //habilidade: troca de lugar
    
    //se primeiro a atacar
        //habilidade
        // o ataque é feito na segunda maldição da fila
    
    // se não
        //ataque padrão
}
