/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feiticeiros;

import abatalhafinal.Feiticeiros;

/**
 *
 * @author 2020122760102
 */
public class Criadores extends Feiticeiros {

    public Criadores(int qtdeArmas, String regiao, String nome, double peso, double altura, int energia, int ataque) {
        super(qtdeArmas, regiao, nome, peso, altura, energia, ataque);
    }
    
    
    
    //retira 10 da life do outro ser atacado
    //habilidade: criar Shikigamis -> Maldições Familiares
        //Shikigamis -> ataque aleatorio de 0 a 30
    
    //ataque -> toda vez que for atacar
        //-10 + ataque aleatorio do Shikigamis
    
    //criador morre, o Shikigamis também morre
    
    //Shikigamis não sofre ataque, o ataque é feito no criador
}
