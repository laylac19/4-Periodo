/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feiticeiros;

import abatalhafinal.Feiticeiros;

/**
 *
 * @author 2020122760102
 */
public class Devastadores extends Feiticeiros {

    public Devastadores(int qtdeArmas, String regiao, String nome, double peso, double altura, int energia, int ataque) {
        super(qtdeArmas, regiao, nome, peso, altura, energia, ataque);
    }
    
    //ataque: 50
    //Habilidade 1: 3 ataque promove "Ataque fatal" = Ultimate -> Maldição morre independentemente da energia que tiver
    // Habilidade 2: antes de atacar ele recupera 20 de energia
        //não passa de 100
}
