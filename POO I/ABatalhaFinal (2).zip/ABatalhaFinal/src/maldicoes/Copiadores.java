/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maldicoes;

import abatalhafinal.Maldicoes;
/**
 *
 * @author 2020122760102
 */
public class Copiadores extends Maldicoes {

    public Copiadores(String obscuro, int qtdeArmas, String nome, double peso, double altura, int energia, int ataque) {
        super(obscuro, qtdeArmas, nome, peso, altura, energia, ataque);
    }
    
    //Habilidade: Replicação de Fila
        //conta o número de feiticeiros e cria esse número de maldições BÁSICAS no final da fila
    
    //não ataca o feiticeiro que atacou
        //Habilidade
    
}
