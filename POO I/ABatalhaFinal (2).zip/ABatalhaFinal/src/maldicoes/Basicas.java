/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maldicoes;

import abatalhafinal.Maldicoes;

/**
 *
 * @author 2020122760102
 */
public class Basicas extends Maldicoes {

    public Basicas(String obscuro, int qtdeArmas, String nome, double peso, double altura, int energia, int ataque) {
        super(obscuro, qtdeArmas, nome, peso, altura, energia, ataque);
    }
    
    //energia comeca: 50
    //ataque: 3
    
}
