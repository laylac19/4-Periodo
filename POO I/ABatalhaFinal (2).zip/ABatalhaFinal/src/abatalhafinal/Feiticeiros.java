/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

/**
 *
 * @author 2020122760102
 */
public abstract class Feiticeiros extends Ser {
    protected int qtdeArmas;
    protected String regiao;
    
    //construtor
    public Feiticeiros(int qtdeArmas, String regiao, String nome, double peso, double altura, int energia, int ataque) {
        super(nome, peso, altura, energia, ataque);
        this.qtdeArmas = qtdeArmas;
        this.regiao = regiao;
    }

    public int getQtdeArmas() {
        return qtdeArmas;
    }

    public String getRegiao() {
        return regiao;
    }
}
