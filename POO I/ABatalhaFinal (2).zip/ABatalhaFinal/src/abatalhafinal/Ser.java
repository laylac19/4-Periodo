/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

//colocar como prote
public abstract class Ser {
    //todo ser tem essas características
    protected String nome;
    protected double peso;
    protected double altura;
    protected int energia; 
    protected int ataque; 

    //construtor
    public Ser(String nome, double peso, double altura, int energia, int ataque) {
        this.nome = nome;
        this.peso = peso;
        this.altura = altura;
        this.energia = energia;
        this.ataque = ataque;
    }
    
    public String getNome() {
        return nome;
    }

    public double getPeso() {
        return peso;
    }

    public double getAltura() {
        return altura;
    }

    public int getEnergia() {
        return energia;
    }

    public int getAtaque() {
        return ataque;
    }
}




