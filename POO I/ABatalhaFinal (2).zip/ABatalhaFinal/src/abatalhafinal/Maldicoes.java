/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abatalhafinal;

//Principal das Maldições
public abstract class Maldicoes extends Ser {
    protected String obscuro; //Nome do principal indivíduo responsável pala criação da maldição
    protected int qtdeArmas;

    //construtor
    public Maldicoes(String obscuro, int qtdeArmas, String nome, double peso, double altura, int energia, int ataque) {
        super(nome, peso, altura, energia, ataque);
        this.obscuro = obscuro;
        this.qtdeArmas = qtdeArmas;
    }

    public String getObscuro() {
        return obscuro;
    }

    public int getQtdeArmas() {
        return qtdeArmas;
    }
}

