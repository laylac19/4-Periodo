/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista1;

import java.text.NumberFormat;
import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double km, valor, diaria, precoKm;
	int dias;

	diaria = 60;
	precoKm = 0.15;
        
        Scanner entrada = new Scanner(System.in);       

	System.out.print("Informe quantos KM foram percorridos: ");
	km = entrada.nextDouble();

	System.out.print("Informe quantos dia está com o carro: ");
	dias = entrada.nextInt();

	// Calcula o valor a pagar, sem considerar o dia quebrado
	valor = dias * diaria + precoKm * km;

        // Para formatar a saída em forma de moeda, com R$
        // Pega o formato da moeda local
        NumberFormat formatoMoeda = NumberFormat.getCurrencyInstance(); 
        
	System.out.println("O valor a pagar: " + formatoMoeda.format(valor));
    }
    
}
