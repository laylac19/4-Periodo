/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista1;

import static java.lang.Math.pow;
import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double a1, an, q, n;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe o 1o termo: ");
	a1 = entrada.nextInt();

	System.out.print("Informe o numero de termos: ");
	n = entrada.nextInt();

	System.out.print("Informe a razao da P.G.: ");
	q = entrada.nextInt();

	// encontra o an, com auxilio da funcao pow()
	an = a1 * pow(q, (n-1));

	System.out.println("O valor de AN eh: " + an);
    }
    
}
