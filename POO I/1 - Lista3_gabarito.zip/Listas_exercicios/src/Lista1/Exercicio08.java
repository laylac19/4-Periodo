/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista1;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double valor_SM, valor_SP, qtde_S;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe o valor do salario minimo: R$ ");
	valor_SM = entrada.nextDouble();

	System.out.print("Informe o valor de seu salario: R$ ");
	valor_SP = entrada.nextDouble();

	// calcula a quantidade de salarios que a pessoa ganha
	qtde_S = valor_SP / valor_SM;
        
        // Para formatar a quantidade de casas decimais
        DecimalFormat formato = new DecimalFormat("#.00"); 

	System.out.println("Voce ganha " + formato.format(qtde_S) + " salarios minimos.");
    }
    
}
