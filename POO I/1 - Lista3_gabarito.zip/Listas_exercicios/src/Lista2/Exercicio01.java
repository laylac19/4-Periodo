/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a, b, s;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe um valor inteiro: ");
	a = entrada.nextInt();
	
        System.out.print("Informe outro valor inteiro: ");
	b = entrada.nextInt();

	// efetua a soma
	s = a + b;

	// checa o resultado da soma
	if(s > 20) {
		System.out.println(s + " eh maior que 20, entao ele passa a valer " + (s+8) );
	}
	else {
		System.out.println(a + " eh menor ou igual a 20, entao ele passa a valer " + (s-5));
	}
    }
    
}
