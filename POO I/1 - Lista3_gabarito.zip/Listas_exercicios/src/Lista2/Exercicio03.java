/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int A, B, C;
	int maior, meio, menor;
        
        Scanner entrada = new Scanner(System.in);

	System.out.print("Informe o valor de A: ");
	A = entrada.nextInt();
        
	System.out.print("Informe o valor de B: ");
	B = entrada.nextInt();
	
        System.out.print("Informe o valor de C: ");
	C = entrada.nextInt();

	// verifica se A eh o maior
	if((A >= B) && (A >= C)){
		maior = A;
		// verifica quem eh o do meio e o menor
		if(B >= C){
			meio = B;
			menor = C;
		}
		else{
			meio = C;
			menor = B;
		}
	}
	// verifica se B eh o maior
	else if((B >= A) && (B >= C)){
		maior = B;
		// verifica quem eh o do meio e o menor
		if(A >= C){
			meio = A;
			menor = C;
		}
		else{
			meio = C;
			menor = A;
		}
	}
	else{
		maior = C;
		// verifica quem eh o do meio e o menor
		if(A >= B){
			meio = A;
			menor = B;
		}
		else{
			meio = B;
			menor = A;
		}
	}
	System.out.println("Os valores em ordem descendente: " + maior + "  " + meio + "  " + menor);
    }
    
}
