/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double n1, n2, n3, n4, n5, maior, menor, media;
        
        Scanner entrada = new Scanner(System.in);

	// Inicialização das variaveis
	maior = -9999;  // muito pequeno
	menor = 9999;   // muito grande
	media = 0;

	// Leitura das notas.
	// Por enquanto não estou preocupado com a validação das notas.
	
        // Sem usar WHILE, porque ainda não vimos.

	// NOTA 1
	System.out.print("\n\tInforme a nota 1: ");
	n1 = entrada.nextDouble();        
        if ( n1 > maior) {
            maior = n1;
        }
        if ( n1 < menor ) {
            menor = n1;
        }

        // NOTA 2
        System.out.print("\n\tInforme a nota 2: ");
        n2 = entrada.nextDouble(); 
        if ( n2 > maior) {
            maior = n2;
        }
        if ( n2 < menor ) {
            menor = n2;
        }

        // NOTA 3
        System.out.print("\n\tInforme a nota 3: ");
        n3 = entrada.nextDouble(); 
        if ( n3 > maior) {
            maior = n3;
        }
        if ( n3 < menor ) {
            menor = n3;
        }

        // NOTA 4
        System.out.print("\n\tInforme a nota 4: ");
        n4 = entrada.nextDouble(); 
        if ( n4 > maior) {
            maior = n4;
        }
        if ( n4 < menor ) {
            menor = n4;
        }

        // NOTA 5
        System.out.print("\n\tInforme a nota 5: ");
        n5 = entrada.nextDouble(); 
        if ( n5 > maior) {
            maior = n5;
        }
        if ( n5 < menor ) {
            menor = n5;
        }

        // Calculo da media, retirando o maior e o menor
        media = ( n1 + n2 + n3 + n4 + n5 - maior - menor ) / 3;

        System.out.println ("\n\tA media das notas e': " +  media);
        System.out.println ("\n\tA maior nota e': " + maior);
        System.out.println ("\n\tA menor nota e': " +  menor);
    }
    
}
