/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe um valor inteiro: ");
	x = entrada.nextInt();

	if((x % 2) == 0){
            System.out.print( x + " eh divisivel por 2");
            // se eh divisivel por 2 e por 5, sera tambem por 10
            if((x % 5) == 0) {
                System.out.println(", por 5 ou por 10");
            }

            System.out.println("\n\n");
	}
	else if((x % 5) == 0){
            System.out.println( x + " eh divisivel por 5");
	}
	else {
            System.out.println( x + " nao eh divisivel por 2, 5 ou 10");
	}
        
    }
    
}
