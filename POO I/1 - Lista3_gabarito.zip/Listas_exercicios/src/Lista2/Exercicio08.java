/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double x;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("\n\tInforme o valor de X: ");
	x = entrada.nextDouble();

	if(x <= 1){
            System.out.println("\n\tf(x) = 1 pois X eh menor ou igual a 1\n\n");
	}
	else if (x <= 2) {
            System.out.println("\n\tf(x) =  2 pois X eh maior que 1 ou menor ou igual a 2\n\n");
	}
	else if (x <= 3) {
            System.out.println("\n\tf(x) =  " + Math.pow(x,2) + " pois X eh maior que 2 ou menor ou igual a 3\n\n" );
	}
	else {
            System.out.println("\n\tf(x) =  " + Math.pow(x,3) + " pois X eh maior que 3\n\n" );
        }
    }
}
