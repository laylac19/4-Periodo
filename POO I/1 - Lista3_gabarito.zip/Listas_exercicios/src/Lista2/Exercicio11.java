/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int mes;
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("\n\tInforme um numero inteiro: ");
	mes = entrada.nextInt();

	switch(mes){
            case 1:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Janeiro.\n\n");
                break;
            case 2:
            	System.out.println("\n\tVoce digitou o numero correspondente ao mes de Fevereiro.\n\n");
                break;
            case 3:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Marco.\n\n");
                break;
            case 4:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Abril.\n\n");
                break;
            case 5:
            	System.out.println("\n\tVoce digitou o numero correspondente ao mes de Maio.\n\n");
                break;
            case 6:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Junho.\n\n");
                break;
            case 7:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Julho\n\n");
                break;
            case 8:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Agosto\n\n");
                break;
            case 9:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Setembro\n\n");
                break;
            case 10:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Outubro\n\n");
                break;
            case 11:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Novembro\n\n");
                break;
            case 12:
		System.out.println("\n\tVoce digitou o numero correspondente ao mes de Dezembro\n\n");
                break;
            default:
		System.out.println("\n\tVoce digitou um numero que nao corresponde a um mes do ano.\n\n");
                break;
	}
    }
    
}
