/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author 1547816
 */
public class Exercicio06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int idade;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("Informe a sua idade: ");
	idade = entrada.nextInt();

	//verifica qual a classe eleitoral do usu�rio
	if ( idade <= 0 ) {
            System.out.println("A idade informada eh INVALIDA!");            
        }
        else if ( idade < 16 ) {
            System.out.println("Voce NAO eh eleitor!");            
	}
        else if ( idade < 18 ) {
            System.out.println("Voce eh um eleitor FACULTATIVO!");            
	}
	else if ( idade < 65 ) {
            System.out.println("Voce eh um eleitor OBRIGATORIO!");            
	}
	else {
            System.out.println("Voce eh um eleitor FACULTATIVO!"); 
	}
    }
    
}
