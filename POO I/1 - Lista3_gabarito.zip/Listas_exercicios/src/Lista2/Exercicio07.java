/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista2;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double n1, n2, n3, media;

        Scanner entrada = new Scanner(System.in);
        
	System.out.print("\tInforme a 1a nota semestral: ");
	n1 = entrada.nextDouble();

	System.out.print("\tInforme a 2a nota semestral: ");
	n2 = entrada.nextDouble();

        System.out.print("\tInforme a 3a nota semestral: ");
	n3 = entrada.nextDouble();
        
	// calcula a m�dia bimestral
	media = (n1 + n2 + n3)/3;

	// verifica a situação do aluno
	if ( media < 0 || media > 10) {
            System.out.println("\n\tMedia invalida: " + media);
	}
	else if ( media < 3 ) {
            System.out.println("\n\tVoce foi Reprovado pois sua media é: " + media);
	}
	else if ( media < 7 ) {
            System.out.println("\n\tVoce deve fazer a Prova Final pois sua media é: " + media);
	}
	else {
	    System.out.println("\n\tVoce foi Aprovado pois sua media é: " + media);
        }
    }
    
}
