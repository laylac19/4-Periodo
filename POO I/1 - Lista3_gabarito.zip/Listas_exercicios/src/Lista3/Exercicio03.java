/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista3;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int qtde, menor, i, valor;
        
        Scanner entrada = new Scanner(System.in);

	menor = 999999;

	// indica a quantidade de n�meros que devem ser digitados
	do {	
            System.out.print("\n\tInforme a quantidade de numeros: ");
            qtde = entrada.nextInt();
	} while ( qtde <= 0);

	// faz a leitura dos valores e encontra o menor
	for ( i = 1; i <= qtde; i++ ) {
		
            // Ler e validar cada valor
            do {
                System.out.print("\tDigite o " + i + "o valor: ");
                valor = entrada.nextInt();
            } while ( valor <= 0) ;

            if(valor <= menor){
                menor = valor;
            }
	}
	System.out.println("\n\tO menor valor digitado foi " + menor);
    }
    
}
