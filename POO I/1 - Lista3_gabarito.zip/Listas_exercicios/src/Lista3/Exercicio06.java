/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista3;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num, i = 1;
        
        Scanner entrada = new Scanner(System.in);

	do {
            System.out.print("Informe o numero de termos da serie: ");
            num = entrada.nextInt();
	} while ( num <= 0 );

	while(num > 0){
            System.out.print(i*i + "\t");
            i++;
            num--;
	}	
	System.out.println("\n");
    }
    
}
