/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista3;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int inferior, superior, i, soma=0;

        Scanner entrada = new Scanner(System.in);
        
	// Ler o limite inferior
	System.out.print("\tInforme o limite inferior: ");
	inferior = entrada.nextInt();

	// Ler e validar o limite SUPERIOR, que deve ser maior que o INFERIOR
	do {
            System.out.print("\tInforme o limite superior: ");
            superior = entrada.nextInt();
	} while ( superior <= inferior );

	System.out.println("\n\tValores pares do intervalo\n");

	// laço for sem inicialização
	for( i = inferior ; i <= superior; i++){
            if ( i % 2 == 0 ) {
                System.out.print(i + "\t");

                // Soma o numero par
                soma = soma + i;
            }
	}
	System.out.println("\n\n\tA soma dos valores do intervalo é: " +  soma);
    }
    
}
