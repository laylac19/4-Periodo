/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista3;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int qt_homens=0, qt_mulheres=0; 
	int qt_homens_DB = 0, qt_mulheres_DB=0;
	int qt_homens_DR = 0, qt_mulheres_DR=0;
	int qt_homens_DI = 0, qt_mulheres_DI=0;
	int qt_aluno_DR, qt_aluno_DI, qt_aluno_DB;
	double nota, soma=0, media=0;
	double porcentagem_DB= 0, porcentagem_DR= 0, porcentagem_DI= 0;
	double porcentagem_homem_DB= 0, porcentagem_homem_DR= 0, porcentagem_homem_DI= 0;
	double porcentagem_mulheres_DB= 0, porcentagem_mulheres_DR= 0, porcentagem_mulheres_DI= 0;		
	char sexo;
	int matricula;
		
	Scanner entrada = new Scanner(System.in);
        
	// A leitura da primeira matricula sera fora do while 
	//	pois ela pode ser uma matricula valida ou negativa, indicando a saida do programa	
	System.out.print("\tEntre com a matrícula do aluno ou -1 para sair: ");
	matricula = entrada.nextInt();
	
	while (matricula > 0 ) {
            // Ler e validar a nota
            do{
                System.out.print("\tInforme a nota do aluno: ");
                nota = entrada.nextDouble();
            } while ( (nota < 0 ) || ( nota > 100 ) );

            soma = soma + nota;

            // Esse do while vai obrigar que o sexo seja f ou m
            do{
                System.out.print("\tDigite o sexo (f para FEMININO e m para MASCULINO): ");
                sexo = entrada.next().toUpperCase().charAt(0);   // Pega o PRIMEIRO caracter de um STRING em MAIUSCULO
            } while ( ( sexo != 'F' ) && ( sexo != 'M' ) );

            // Se for homem
            if  ( sexo == 'M' ) { 
                qt_homens++;
                if (nota >= 80) {
                        qt_homens_DB++;
                }
                else if (nota >= 60) {
                        qt_homens_DR++;	
                }
                else {
                        qt_homens_DI++;
                }
            } 
            else { // Se for mulher
                qt_mulheres++;
                if (nota >= 80) {
                        qt_mulheres_DB++;
                }
                else if (nota >= 60) {
                        qt_mulheres_DR++;	
                } 
                else {
                        qt_mulheres_DI++;
                }
            }
            System.out.print("\n\tEntre com a matrícula do próximo aluno ou -1 para sair: ");
            matricula = entrada.nextInt();
	}
	
	System.out.println("\n\tA quantidade de homens é: " + qt_homens);
	System.out.println("\tA quantidade de mulheres é: " + qt_mulheres);

	// Evitando divisão por 0
	if ( (qt_homens + qt_mulheres) > 0 )
            media = soma / (qt_homens + qt_mulheres);
	System.out.println("\n\tA media das notas é: " + media);
	
	qt_aluno_DB = qt_homens_DB + qt_mulheres_DB;
	qt_aluno_DR = qt_homens_DR + qt_mulheres_DR;
	qt_aluno_DI = qt_homens_DI + qt_mulheres_DI;	
	System.out.println("\n\tA quantidade de alunos DB é: " + qt_aluno_DB);
	System.out.println("\tA quantidade de alunos DR é: " + qt_aluno_DR);
	System.out.println("\tA quantidade de alunos DI é: " + qt_aluno_DI);
			
	// Evitando divisão�o por 0
	if ( (qt_homens + qt_mulheres) > 0 ) {
            porcentagem_DB = (double) qt_aluno_DB / (qt_homens + qt_mulheres);
            porcentagem_DR = (double) qt_aluno_DR / (qt_homens + qt_mulheres);
            porcentagem_DI = (double) qt_aluno_DI / (qt_homens + qt_mulheres);
	}

	// Evitando divisão�o por 0
	if (qt_homens > 0) {
            porcentagem_homem_DB = (double) qt_homens_DB / qt_homens;
            porcentagem_homem_DR = (double) qt_homens_DR / qt_homens;
            porcentagem_homem_DI = (double) qt_homens_DI / qt_homens;		
	}

	// Evitando divisão�o por 0
	if (qt_mulheres > 0) {
            porcentagem_mulheres_DB = (double) qt_mulheres_DB / qt_mulheres;
            porcentagem_mulheres_DR = (double) qt_mulheres_DR / qt_mulheres;
            porcentagem_mulheres_DI = (double) qt_mulheres_DI / qt_mulheres;		
	}

	
	System.out.println("\n\tA porcentagem de alunos DB é: " + 100*porcentagem_DB);
	System.out.println("\tA porcentagem de alunos DR é: " + 100*porcentagem_DR);
	System.out.println("\tA porcentagem de alunos DI é: " + 100*porcentagem_DI);

	System.out.println("\n\tA porcentagem de homens DB é: " + 100*porcentagem_homem_DB);
	System.out.println("\tA porcentagem de homens DR é: " + 100*porcentagem_homem_DR);
	System.out.println("\tA porcentagem de homens DI é: " + 100*porcentagem_homem_DI);
	
	System.out.println("\n\tA porcentagem de mulheres DB é: " + 100*porcentagem_mulheres_DB);
	System.out.println("\tA porcentagem de mulheres DR é: " + 100*porcentagem_mulheres_DR);
	System.out.println("\tA porcentagem de mulheres DI é: " + 100*porcentagem_mulheres_DI);
	
    }
    
}
