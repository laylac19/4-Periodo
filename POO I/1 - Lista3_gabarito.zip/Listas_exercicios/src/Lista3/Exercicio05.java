/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista3;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Fatorial de um numero
        int i, n, fat;

        Scanner entrada = new Scanner(System.in);
        
        do {
            System.out.print("\tInforme o numero: ");
            n = entrada.nextInt();
        } while ( n <= 0 );

        fat = 1;

        for ( i = n ; i > 1 ; i--) {
            fat = fat * i;
        }
        System.out.println("\n\tO fatorial é: " + fat );
    }
    
}
