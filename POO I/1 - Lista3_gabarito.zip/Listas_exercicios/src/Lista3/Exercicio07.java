/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista3;

import java.util.Scanner;

/**
 *
 * @author jean_
 */
public class Exercicio07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declaração e iniciaizacao das variaveis
	int cod = 0;    	// Ler o Codigo do cliente
	int cont = 0 ;          // Contador de clientes
	double peso = 0.0 ;   	// Ler o peso
	double altura = 0.0 ; 	// Ler a altura
	double mediaPeso = 0.0;	// Media de pesos
	double mediaAltura = 0.0; // Media de alturas
        
        Scanner entrada = new Scanner(System.in);
        	
	/* 	Vari�veis para armazenar o MAIS ALTO.
		No in�cio o mais alto � ZERO, para o primeiro a ser lido 
		ser mais alto que essa vari�vel
	*/
	double maisAlto = 0.0;
	int codMaisAlto = 0;
	
	/* 	Vari�veis para armazenar o MAIS BAIXO.
		No in�cio o mais baixo � um valor alto, por exemplo 5, 
		para o primeiro a ser lido ser mais baixo que essa vari�vel
	*/
	double maisBaixo = 5.0;
	int codMaisBaixo = 0;
	
	/*	Vari�veis para armazenar o MAIS GORDO.
		No in�cio o mais gordo � ZERO, para o primeiro a ser lido 
		ser mais gordo que essa vari�vel
	*/
	double maisGordo = 0.0;
	int codMaisGordo = 0;
	
	/* 	Vari�veis para armazenar o MAIS MAGRO. 
		No in�cio o mais magro � um valor alto, por exemplo 500, 
		para o primeiro a ser lido ser mais magro que essa vari�vel
	*/
	double maisMagro = 500.0;
	int codMaisMagro = 0;
	
	// Ler e validar o primeiro codigo
	do{
		System.out.print("\tInforme o código do cliente: ");
		cod = entrada.nextInt();
	} while ( cod < 0 );
		 
	// Vou repetir ate o codigo digitado for igual a ZERO		 
	while (cod > 0 ) {

            // Ler e validar o peso
            do {
                System.out.print("\tInforme o peso do cliente: ");
                peso = entrada.nextDouble();
            } while ( peso <= 0 || peso >= 500 );

            // Ler e validar a altura
            do {
                System.out.print("\tInforme a altura do cliente: ");
                altura = entrada.nextDouble();	
            } while ( altura <= 0.1 || altura >= 2.5 );
	      	
	    mediaPeso = mediaPeso + peso;
	    mediaAltura = mediaAltura + altura;
	
	    cont = cont + 1;
	
	    // Verificar se é mais ALTO
	    if ( altura > maisAlto ) {
	        maisAlto = altura;
	        codMaisAlto = cod;
	    }
	
	    // Verificar se é mais BAIXO
	    if ( altura < maisBaixo ) {		
	        maisBaixo = altura;
	        codMaisBaixo = cod;
	    }
	
	    // Verificar se é mais GORDO
	    if ( peso > maisGordo ) {
	        maisGordo = peso;
	        codMaisGordo = cod;
	    }
	
	    // Verificar se é mais MAGRO
	    if ( peso < maisMagro ) {
	        maisMagro = peso;
	        codMaisMagro = cod;
            }
	    
            // Ler e validar o PROXIMO codigo
            do{
                System.out.print("\n\tInforme o código do cliente: ");
                cod = entrada.nextInt();
            } while ( cod < 0 );

	}
	// Fim do WHILE
	
	//Imprimir as informações	
	if ( cont > 0 ) {
	    mediaPeso = mediaPeso / cont;
	    mediaAltura = mediaAltura / cont;
	
	    System.out.println("\n\tMAIS ALTO: " + codMaisAlto);
	    System.out.println("\tAltura: " + maisAlto);
	
	    System.out.println("\n\tMAIS BAIXO: " + codMaisBaixo);
	    System.out.println("\tAltura: " + maisBaixo);
	
	    System.out.println("\n\tMAIS GORDO: " + codMaisGordo);
	    System.out.println("\tPeso: " + maisGordo);
	
	    System.out.println("\n\tMAIS MAGRO: " + codMaisMagro);
	    System.out.println("\tPeso: " + maisMagro);
	
	    System.out.println("\n\tMÉDIA DAS ALTURAS: " + mediaAltura);
	    System.out.println("\tMÉDIA DOS PESOS: " + mediaPeso);
	}
	else {
	    System.out.println("\n\tNinguém foi cadastrado.\n\n");
	}
    }
    
}
